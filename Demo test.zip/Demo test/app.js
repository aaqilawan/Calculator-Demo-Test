// Tooltips
var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
  return new bootstrap.Tooltip(tooltipTriggerEl)
})

// Counter Demo
let decrement = document.querySelectorAll(".decre");
let increment = document.querySelectorAll(".incre");

// for increment
for (let i = 0; i < increment.length; i++) {
  let btn = increment[i];
  btn.addEventListener('click',(e)=>{
    let click = e.target;
    let input = click.parentElement.children[2];
    let inputValue = input.value;
    let newValue = parseInt(inputValue) + 1;
    input.value = newValue;
  })
}
// for decrement
for (let i = 0; i < decrement.length; i++) {
  let btn = decrement[i];
  btn.addEventListener('click',(e)=>{
    let click = e.target;
    let input = click.parentElement.children[2];
    let inputValue = input.value;
    let newValue = parseInt(inputValue) - 1;
    input.value = newValue;
  })
}